'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;
const autoIncrementModelID = require('./counterModel');

var TaskSchema = new Schema({
    id: {
        type: Number,
        min: 1,
        unique: true,


    },
    name: {
        type: String,
        required: 'Kindly enter the name of the product'
    },
    description: {
        type: String,
        required: 'enter product description'
    },
    price: {
        type: String,
        required: 'price',
    },
    quantity: {
        type: String,
        required: 'quanity'
    },

    Created_date: {
        type: Date,
        default: Date.now
    },

    status: {
        type: [{
            type: String,
            enum: ['approved', 'pending']
        }],
        default: ['pending']
    }
});
TaskSchema.pre('save', function(next) {
    if (!this.isNew) {
        next();
        return;
    }

    autoIncrementModelID('activities', this, next);
});
module.exports = mongoose.model('Tasks', TaskSchema);