'use strict';
module.exports = function(app) {
    var productlist = require('../controllers/productListController');

    // todoList Routes
    app.route('/products')
        .get(productlist.listProducts)
        .post(productlist.createProduct);


    app.route('/products/:productId')
        .get(productlist.fetchSingleProduct)
        .put(productlist.updateProduct)
        .delete(productlist.deleteProduct);

    // app.route('/count')
    //     .get(productlist.count_all_tasks);
};