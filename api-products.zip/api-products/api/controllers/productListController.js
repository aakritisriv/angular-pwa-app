'use strict';


var mongoose = require('mongoose'),
    Task = mongoose.model('Tasks');

exports.listProducts = function(req, res) {
    Task.find({}, function(err, task) {
        if (err)
            res.send(err);
        res.json(task);
    });
};

// exports.count_all_tasks = function(req, res) {
//     Task.count({}, function(err, task) {
//         if (err) {
//             console.log(err);
//         } else {
//             res.json("Number of total tasks : " + task);
//         }
//     });
// };
// exports.count_by_status = function(req, res) {
//     Task.count({}, function(err, result) {
//         if (err) {
//             res.send(err);
//         } else {
//             res.json(result);
//         }
//     });
// };
exports.createProduct = function(req, res) {

    var new_task = new Task(req.body);
    new_task.save(function(err, task) {
        if (err)
            res.send(err);
        res.json(task);
    });
};


exports.fetchSingleProduct = function(req, res) {
    Task.findOne({ id: req.params.productId }, function(err, task) {
        if (err)
            res.send(err);
        res.json(task);
    });
};


exports.updateProduct = function(req, res) {
    Task.findOneAndUpdate({ id: req.params.productId }, req.body, { new: true }, function(err, task) {
        if (err)
            res.send(err);
        res.json({ msg: 'Updated successfully' });
    });
};


exports.deleteProduct = function(req, res) {


    Task.remove({
        id: req.params.productId
    }, function(err, task) {
        if (err)
            res.send(err);
        res.json({ message: 'Product successfully deleted' });
    });
};